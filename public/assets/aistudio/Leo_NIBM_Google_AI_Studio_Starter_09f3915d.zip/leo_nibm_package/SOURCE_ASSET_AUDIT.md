# Source asset audit - uploaded Leo.zip

Inspected the uploaded `/mnt/data/Leo.zip` archive. It contains 56 top-level ZIP entries including nested archives.

## Identity and brand images extracted into this package

- `Leo_Club_of_NIBM_logo.png` - 165 x 217, older club logo version.
- `Leo_Club_of_NIBM_logo_transparent.png` - 165 x 217, transparent-background older club logo version.
- `NIBM_logo.png` - 322 x 198.
- `NIBM_logo_transparent.png` - 322 x 198.
- `Official Logos/Leo Logo.png` - Leo emblem.
- `Official Logos/Lion Logo.png` - Lions emblem.
- `Official Logos/Leos of Sri Lanka & Maldives_Primary Version.png`.
- `Official Logos/Leos of D7_Black Version.png`.
- `Official Logos/Leos of D7_White Version.png`.
- `WhatsApp Image 2026-11-12 at 13.34.11.jpeg` - 500 x 500 updated Leo Club of NIBM logo artwork with District 306 D7 wording. This is the current logo used in the starter UI; request the high-resolution/vector source before launch.
- `WhatsApp Image 2026-10-27 at 16.50.16.jpeg` - 1600 x 533 horizontal logo lockup showing NIBM, Leo Club of NIBM, Lions International, a District President mark and Leos of Sri Lanka & Maldives. Treat this as a supplied artwork/lockup; confirm the correct placement context under the current district branding guide.

## Other resource groups

- Club administration, MyLEO, secretary, treasurer and meetings guides.
- Three 2026/27 joint-project approval form types.
- 2026/27 award attributes.
- Branding Guidelines 2026/27 and Branding Kit_Leo District 306 D7.
- Contact-directory workbooks including Club President Details, District Executive Committee, D7 District Council and Multiple District Executive Committee.
- District President annual plan/event calendar.
- Leo Club resource guides, pledges and anthem.
- District leadership biographies.

## Asset conclusion

The two WhatsApp images are branding artwork, not project-photo albums. The ZIP does not contain a complete current NIBM project portfolio with project names, project descriptions, verified outcomes and image galleries. Use real club project assets supplied separately by the committee before publishing project stories.
