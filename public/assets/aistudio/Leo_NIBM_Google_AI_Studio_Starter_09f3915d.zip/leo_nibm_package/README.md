# Leo Club of NIBM - Google AI Studio starter package

This package is a React + TypeScript website starter and implementation guide for building the Leo Club of NIBM website in **Google AI Studio Build Mode**.

## Important scope

- The website uses the SLIIT Leo site as its broad interface/interaction reference.
- The project section intentionally has **no map**. Projects are presented as conventional editorial cards and individual project-story pages with photos, videos, impact details and related stories.
- The Kolonnawa Witness URL is a newsletter/publication reference. The conventional project detail pattern is better represented by Kolonnawa's Projects archive and its project article pages.
- The starter includes public pages and the core Firebase-oriented project-admin workflow (Google sign-in, project records, multiple image/video upload and project detail presentation). It is a starter scaffold, not a finished production application. The remaining admin CRUD modules (events, team, gallery management, publications, awards, membership enquiry administration and full site settings) are specified in the master prompt and prompt sequence for Google AI Studio to complete and test.
- No real NIBM projects, impact numbers, officer biographies or event records have been fabricated. Public pages show honest empty states until approved content is entered.

## Package contents

- `AI_STUDIO_MASTER_PROMPT.md` - complete build brief to give Google AI Studio.
- `PROMPT_SEQUENCE.md` - step-by-step prompts to use during development.
- `REFERENCE_SCREENSHOT_CHECKLIST.md` - what screenshots to capture if AI Studio cannot inspect the SLIIT reference directly.
- `docs/Leo_Club_of_NIBM_Google_AI_Studio_Build_Blueprint.pdf` - printable build specification.
- `src/` - React + TypeScript starter source.
- `firestore.rules` - example role-aware Firestore rules.
- `storage.rules` - example public-media/private-document storage rules.
- `.env.example` - Vite/Firebase configuration example for use outside native AI Studio provisioning.
- `assets/` and `public/assets/` - copied NIBM, Leo and district brand images from the uploaded `Leo.zip`.

## Recommended way to use it in Google AI Studio

### Option A - Build a new app using the master prompt (recommended)

1. Open [Google AI Studio](https://aistudio.google.com/) and switch to **Build**.
2. Choose **Web app**. Do not choose Android.
3. Open `AI_STUDIO_MASTER_PROMPT.md` and paste the full prompt into Build Mode.
4. Add the supplied NIBM logo assets as files if AI Studio does not preserve the included assets automatically.
5. Open the two reference sites. If AI Studio cannot view the live SLIIT interface, capture the screenshots listed in `REFERENCE_SCREENSHOT_CHECKLIST.md` and attach them to the chat.
6. Let AI Studio create the first version and inspect the live preview.
7. Use `PROMPT_SEQUENCE.md` and submit prompts one by one. Do not ask it to generate every backend/admin function in one huge follow-up.
7. When AI Studio displays the Firebase setup card, enable Firestore and Google Authentication. Read the location warning carefully; the Firestore location is permanent.
8. Set up Cloud Storage only after reading the billing warning in the section below.

### Option B - Continue from the starter code

1. Extract this ZIP on your computer.
2. Put the folder in a GitHub repository (do not commit secrets or `.env` files).
3. In Google AI Studio Build Mode, use the `+` / Add files menu and choose **Import from GitHub**.
4. Import the repository, then paste the prompts from `PROMPT_SEQUENCE.md` one at a time to adapt the Firebase integration and complete the remaining modules.

Google AI Studio's generated Firebase config can differ from a normal Vite setup. If AI Studio created `src/lib/firebase.ts` or another Firebase setup file, **reuse that generated configuration**. Do not initialise a second Firebase app. The provided `src/lib/firebase.ts` is a Vite environment-variable starter; AI Studio may need to adapt it to the generated project config.

## Firebase setup and costs

### Firestore and Google sign-in

Google AI Studio Build Mode can set up Cloud Firestore and Firebase Authentication (Google sign-in) for web apps. When prompted, choose a suitable Asia region. `asia-south1` (Mumbai) is an available Firestore regional location; verify it is offered in the setup dialog before choosing. **Firestore location cannot be changed after creation.**

### Cloud Storage for uploaded photos/videos

Cloud Storage for Firebase is used for persistent image and video uploads. Current Firebase documentation says Cloud Storage for Firebase requires the **Blaze pay-as-you-go plan** to provision/use a default bucket. There may be no-cost usage allowances, but a billing account is still required and overages can incur charges. Do not upgrade or enable billing until the club/project owner has reviewed the current pricing and budget.

If the club does not want a billing-enabled Firebase project, choose a separately approved media host and adapt the upload service. Do not simulate persistent uploads with browser localStorage.

### First Super Admin

1. Enable Google Authentication.
2. Sign in once using the intended first administrator Google account.
3. In Firebase Console > Firestore, obtain that user's Firebase Authentication UID.
4. Create a document in `users` with the document ID equal to that UID. Example fields:

```json
{
  "email": "approved-admin@example.com",
  "displayName": "Approved Club Administrator",
  "role": "superAdmin",
  "active": true
}
```

5. Sign out and sign in again. The app should now allow access to `/admin`.
6. Do not let users choose or edit their own roles in the browser. Role grants must be performed by the current Super Admin through a controlled process.

Replace the example email above with the actual authorised account. Do not create a public admin-registration form.

## Storage paths and safety

- `public-media/projects/{projectId}/...` - approved public project images/videos. Any person with a file URL may be able to view these, so upload only content approved for public release.
- `private-documents/...` - approval documents, invoices, attendance sheets and internal records. These must remain restricted.
- Do not upload signatures, member lists, addresses, personal phone numbers or financial records into public storage.
- Obtain photo/video permissions, especially when images show children or vulnerable people.

Review the provided `firestore.rules` and `storage.rules` before deployment. They are a starting point, not a substitute for testing in the Firebase Rules Playground/emulator and reviewing the final rules produced by AI Studio.

## Local development

For a normal Vite environment:

```bash
npm install
cp .env.example .env.local
# Fill the Firebase web-app values in .env.local
npm run dev
```

For Windows PowerShell, copy `.env.example` to `.env.local` manually, then edit the file. Do not commit `.env.local`.

Build check:

```bash
npm run build
```

This session did not install dependencies or run the Vite build because the container could not resolve npm registry hosts. The source was checked for obvious TypeScript/JSX syntax issues, but this package must still be installed and built in AI Studio or on your machine before deployment.

## Project workflow currently included in the starter

- Google sign-in.
- Admin role check against `users/{uid}`.
- Project draft creation and editing.
- Multi-file image/video upload to Firebase Storage.
- Image/video media records linked to Firestore project documents.
- Captions, alt text, image ordering and removal for saved media.
- Project publication states and publish access limited to Super Admin/President/Secretary.
- Public project archive and individual project detail pages.
- Gallery and project video presentation.

Google AI Studio should complete the remaining editor refinements and the additional admin modules according to the specification.

## Do not publish until

- Current NIBM officers and contact details have been confirmed.
- The current NIBM annual theme is confirmed (do not assume it is the D7 theme).
- The official current club logo lockup has been approved.
- Actual project reports, photos, impact figures and partner details have been supplied and approved.
- Firebase rules, Storage rules and admin-role access have been tested.
- Expected Firebase Storage/Cloud Run billing has been reviewed.
