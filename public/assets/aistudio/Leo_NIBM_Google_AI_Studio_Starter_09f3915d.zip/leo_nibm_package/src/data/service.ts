import {
  addDoc, collection, deleteDoc, doc, getDoc, getDocs, orderBy, query,
  serverTimestamp, setDoc, updateDoc, where,
} from 'firebase/firestore';
import {
  getDownloadURL, ref, uploadBytesResumable, deleteObject,
} from 'firebase/storage';
import { requireFirebase } from '../lib/firebase';
import type { ClubEvent, Officer, Project, ProjectMedia, Publication, UserProfile } from '../types';

const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const MAX_VIDEO_BYTES = 100 * 1024 * 1024;
const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];

function toProject(id: string, data: Record<string, unknown>): Project {
  return { id, ...(data as Omit<Project, 'id'>) };
}

export async function getPublicProjects(): Promise<Project[]> {
  const { db } = requireFirebase();
  const q = query(collection(db, 'projects'), where('publicationStatus', '==', 'published'), orderBy('startDate', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((item) => toProject(item.id, item.data() as Record<string, unknown>));
}

export async function getAllProjectsForAdmin(): Promise<Project[]> {
  const { db } = requireFirebase();
  const q = query(collection(db, 'projects'), orderBy('updatedAt', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((item) => toProject(item.id, item.data() as Record<string, unknown>));
}

export async function getProjectBySlug(slug: string): Promise<Project | null> {
  const { db } = requireFirebase();
  const q = query(collection(db, 'projects'), where('slug', '==', slug), where('publicationStatus', '==', 'published'));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  const item = snap.docs[0];
  return toProject(item.id, item.data() as Record<string, unknown>);
}

export async function saveProject(project: Partial<Project> & { id?: string }): Promise<string> {
  const { db } = requireFirebase();
  const { id, ...payload } = project;
  const definedPayload = Object.fromEntries(Object.entries(payload).filter(([, value]) => value !== undefined));
  const clean = {
    ...definedPayload,
    updatedAt: Date.now(),
    updatedAtServer: serverTimestamp(),
    ...(id ? {} : { createdAt: Date.now(), createdAtServer: serverTimestamp() }),
  };
  if (id) {
    await updateDoc(doc(db, 'projects', id), clean);
    return id;
  }
  const created = await addDoc(collection(db, 'projects'), clean);
  return created.id;
}

export async function setProjectPublicationStatus(id: string, status: Project['publicationStatus']) {
  const { db } = requireFirebase();
  await updateDoc(doc(db, 'projects', id), { publicationStatus: status, updatedAt: Date.now(), updatedAtServer: serverTimestamp() });
}

export async function deleteProject(id: string) {
  const { db } = requireFirebase();
  await deleteDoc(doc(db, 'projects', id));
}

export async function uploadProjectMedia(
  projectId: string,
  files: FileList | File[],
  onProgress?: (fileIndex: number, percent: number) => void,
): Promise<ProjectMedia[]> {
  const { storage } = requireFirebase();
  const selected = Array.from(files);
  const uploaded: ProjectMedia[] = [];

  for (let index = 0; index < selected.length; index += 1) {
    const file = selected[index];
    const isImage = IMAGE_TYPES.includes(file.type);
    const isVideo = VIDEO_TYPES.includes(file.type);
    if (!isImage && !isVideo) throw new Error(`${file.name}: use JPG, PNG, WebP, MP4, WebM or MOV.`);
    const maxBytes = isImage ? MAX_IMAGE_BYTES : MAX_VIDEO_BYTES;
    if (file.size > maxBytes) throw new Error(`${file.name}: file is larger than the ${isImage ? '20 MB image' : '100 MB video'} limit.`);

    const safeName = file.name.toLowerCase().replace(/[^a-z0-9._-]+/g, '-');
    const path = `public-media/projects/${projectId}/${Date.now()}-${index}-${safeName}`;
    const storageRef = ref(storage, path);
    await new Promise<void>((resolve, reject) => {
      const task = uploadBytesResumable(storageRef, file, { contentType: file.type });
      task.on('state_changed', (snapshot) => {
        const percent = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
        onProgress?.(index, percent);
      }, reject, () => resolve());
    });
    const url = await getDownloadURL(storageRef);
    uploaded.push({
      id: `${Date.now()}-${index}`,
      url,
      storagePath: path,
      type: isImage ? 'image' : 'video',
      caption: '',
      altText: file.name,
      order: index,
    });
  }
  return uploaded;
}

export async function removeUploadedMedia(path?: string) {
  if (!path) return;
  const { storage } = requireFirebase();
  await deleteObject(ref(storage, path));
}

export async function getCurrentUserProfile(uid: string): Promise<UserProfile | null> {
  const { db } = requireFirebase();
  const snap = await getDoc(doc(db, 'users', uid));
  if (!snap.exists()) return null;
  return { uid, ...(snap.data() as Omit<UserProfile, 'uid'>) };
}

export async function getPublicEvents(): Promise<ClubEvent[]> {
  const { db } = requireFirebase();
  const q = query(collection(db, 'events'), where('publicationStatus', '==', 'published'), orderBy('date', 'asc'));
  const snap = await getDocs(q);
  return snap.docs.map((item) => ({ id: item.id, ...(item.data() as Omit<ClubEvent, 'id'>) }));
}

export async function getPublicOfficers(): Promise<Officer[]> {
  const { db } = requireFirebase();
  const q = query(collection(db, 'officers'), where('visible', '==', true), orderBy('displayOrder', 'asc'));
  const snap = await getDocs(q);
  return snap.docs.map((item) => ({ id: item.id, ...(item.data() as Omit<Officer, 'id'>) }));
}

export async function getPublications(): Promise<Publication[]> {
  const { db } = requireFirebase();
  const q = query(collection(db, 'publications'), where('publicationStatus', '==', 'published'), orderBy('date', 'desc'));
  const snap = await getDocs(q);
  return snap.docs.map((item) => ({ id: item.id, ...(item.data() as Omit<Publication, 'id'>) }));
}

export async function createMembershipEnquiry(data: Record<string, string>) {
  const { db } = requireFirebase();
  await addDoc(collection(db, 'membershipEnquiries'), { ...data, createdAt: serverTimestamp(), status: 'new' });
}

export async function saveOfficer(officer: Partial<Officer> & { id?: string }) {
  const { db } = requireFirebase();
  const { id, ...payload } = officer;
  if (id) await setDoc(doc(db, 'officers', id), { ...payload, updatedAt: serverTimestamp() }, { merge: true });
  else await addDoc(collection(db, 'officers'), { ...payload, createdAt: serverTimestamp() });
}
