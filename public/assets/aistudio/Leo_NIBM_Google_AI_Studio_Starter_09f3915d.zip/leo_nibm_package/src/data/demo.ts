import type { ClubEvent, Officer, Project, Publication } from '../types';

// Empty, explicitly labelled development data. Do not replace these with invented
// club achievements. Add verified NIBM records through the admin dashboard.
export const demoProjects: Project[] = [];
export const demoEvents: ClubEvent[] = [];
export const demoOfficers: Officer[] = [];
export const demoPublications: Publication[] = [];
