import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { auth, db, firebaseReady, googleProvider, requireFirebase } from '../lib/firebase';
import { getAllProjectsForAdmin, getCurrentUserProfile, removeUploadedMedia, saveProject, setProjectPublicationStatus, uploadProjectMedia } from '../data/service';
import type { Project, ProjectStatus, UserProfile } from '../types';
import { ArrowLeft, ArrowUpRight, Check, ChevronDown, ChevronUp, FilePlus2, ImagePlus, LogOut, RefreshCw, ShieldCheck, UploadCloud, Video, X } from 'lucide-react';

const projectCategories = [
  'Children and Youth','Environment and Sustainability','Health and Nutrition','Peace and Culture','Sports and Recreation','Senior Citizens','Disability Support','Education and Literacy','Women Empowerment','Poverty and Community Development','Safety and Crime Prevention','Infrastructure','Research and Innovation','Drug Prevention','Animals and Wildlife','Fellowship and Community Engagement','Hunger and Food Security','Vision Care','Disaster Management','Fundraising','Public Relations',
];

function slugify(value: string) { return value.toLowerCase().trim().normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,''); }

export default function AdminPage() {
  const [user,setUser] = useState<User|null>(null);
  const [profile,setProfile] = useState<UserProfile|null>(null);
  const [authLoading,setAuthLoading] = useState(true);
  const [projects,setProjects] = useState<Project[]>([]);
  const [loading,setLoading] = useState(false);
  const [showForm,setShowForm] = useState(false);
  const [editing,setEditing] = useState<Project|null>(null);
  const [notice,setNotice] = useState('');
  const canEdit = !!profile?.active && ['superAdmin','president','secretary','projectEditor','mediaEditor'].includes(profile.role);
  const canPublish = !!profile?.active && ['superAdmin','president','secretary'].includes(profile.role);

  useEffect(()=>{
    if (!auth) { setAuthLoading(false); return; }
    return onAuthStateChanged(auth, async nextUser=>{
      setUser(nextUser); setProfile(null); setAuthLoading(true);
      if (nextUser) {
        try { setProfile(await getCurrentUserProfile(nextUser.uid)); }
        catch (err) { console.error(err); }
      }
      setAuthLoading(false);
    });
  },[]);

  async function loadProjects() {
    if (!canEdit) return;
    setLoading(true);
    try { setProjects(await getAllProjectsForAdmin()); }
    catch (err) { setNotice(err instanceof Error?err.message:'Could not load projects.'); }
    finally { setLoading(false); }
  }
  useEffect(()=>{ void loadProjects(); },[profile?.uid]);

  async function login() {
    if (!auth) return;
    try { await signInWithPopup(auth,googleProvider); }
    catch (err) { setNotice(err instanceof Error?err.message:'Google sign-in failed.'); }
  }

  if (!firebaseReady || !auth || !db) return <div className="admin-page"><div className="admin-card"><ShieldCheck size={35}/><span className="section-kicker">ADMIN CONFIGURATION</span><h1>Connect the club workspace.</h1><p>This starter is not connected to Firebase yet. In Google AI Studio, enable the Firebase integration for Authentication and Firestore, then configure Cloud Storage for project photos and videos. Keep the generated Firebase configuration and adapt <code>src/lib/firebase.ts</code>.</p><Link to="/" className="text-link"><ArrowLeft size={15}/> Back to website</Link></div></div>;
  if (authLoading) return <div className="admin-page"><div className="admin-card">Checking administrator access…</div></div>;
  if (!user) return <div className="admin-page"><div className="admin-card"><div className="admin-mark"><ShieldCheck/></div><span className="section-kicker">SECURE CLUB ADMINISTRATION</span><h1>Welcome back.</h1><p>Sign in with the Google account that has been approved by the Leo Club of NIBM website administrator.</p><button className="button button-dark" onClick={login}>Continue with Google <ArrowUpRight size={16}/></button><Link to="/" className="text-link"><ArrowLeft size={15}/> Return to website</Link></div></div>;
  if (!profile || !profile.active) return <div className="admin-page"><div className="admin-card"><ShieldCheck size={35}/><span className="section-kicker">ACCESS NOT GRANTED</span><h1>Account awaiting approval.</h1><p>You are signed in as <b>{user.email}</b>, but this account does not have an active admin role. Ask the Super Admin to create or activate your user profile in Firestore. Do not try to assign your own role from the browser.</p><button className="button button-dark" onClick={()=>signOut(auth)}>Sign out <LogOut size={16}/></button></div></div>;

  return <div className="admin-page admin-console">
    <div className="admin-topbar"><div><span className="section-kicker">LEO CLUB OF NIBM</span><h1>Content studio</h1></div><div className="admin-user"><span>{user.displayName || user.email}</span><button onClick={()=>signOut(auth)} aria-label="Sign out"><LogOut size={17}/></button></div></div>
    <div className="admin-shell">
      <aside className="admin-sidebar"><div className="admin-side-label">CONTENT</div><button className="admin-side-active"><FilePlus2 size={17}/> Projects</button><button disabled title="Add through the next content-management phase">Events <small>Planned</small></button><button disabled title="Add through the next content-management phase">Our Team <small>Planned</small></button><button disabled title="Add through the next content-management phase">Publications <small>Planned</small></button><div className="admin-side-label">ACCOUNT</div><div className="role-chip"><ShieldCheck size={15}/>{profile.role}</div><small className="admin-side-note">Other content modules are included in the build specification and should be added after the core project workflow is verified.</small></aside>
      <section className="admin-content">
        {notice && <div className="admin-notice" role="status">{notice}<button onClick={()=>setNotice('')}><X size={14}/></button></div>}
        {showForm ? <ProjectForm editing={editing} canPublish={canPublish} onCancel={()=>{setShowForm(false);setEditing(null);}} onSaved={async()=>{setShowForm(false);setEditing(null);await loadProjects();setNotice('Project saved.');}} onError={setNotice}/> : <>
          <div className="admin-content-heading"><div><span className="section-kicker">PROJECT MANAGEMENT</span><h2>Project stories</h2><p>Create, edit and submit NIBM project stories for public publication.</p></div><button className="button button-dark" onClick={()=>{setEditing(null);setShowForm(true);}}><FilePlus2 size={16}/> Add project</button></div>
          <div className="admin-table-head"><span>PROJECT</span><span>ACTIVITY</span><span>PUBLICATION</span><span>ACTION</span></div>
          {loading ? <div className="loading-note">Loading project records…</div> : projects.length ? projects.map(p=><div className="admin-project-row" key={p.id}><div className="admin-project-name"><div className="admin-thumb">{p.coverImage?<img src={p.coverImage} alt=""/>:<ImagePlus/>}</div><div><b>{p.title}</b><small>{p.category} · {p.leosticYear}</small></div></div><span className="status-text">{p.status}</span><span className={`publication-pill ${p.publicationStatus}`}>{p.publicationStatus}</span><div className="row-actions"><button onClick={()=>{setEditing(p);setShowForm(true);}}>Edit</button>{canPublish && p.publicationStatus!=='published' && <button onClick={async()=>{try{await setProjectPublicationStatus(p.id,'published');await loadProjects();}catch(e){setNotice(e instanceof Error?e.message:'Publish failed.');}}}>Publish</button>}</div></div>) : <div className="empty-state"><span className="empty-icon"><FilePlus2/></span><h3>No project records yet</h3><p>Create the first project record. Add verified details and media, then submit it for review.</p><button className="button button-gold" onClick={()=>setShowForm(true)}>Create first project <ArrowUpRight size={16}/></button></div>}
          <button className="refresh-link" onClick={loadProjects}><RefreshCw size={14}/> Refresh records</button>
        </>}
      </section>
    </div>
  </div>;
}

function ProjectForm({ editing, canPublish, onCancel, onSaved, onError }: { editing: Project|null; canPublish: boolean; onCancel:()=>void; onSaved:()=>void; onError:(message:string)=>void }) {
  const [busy,setBusy] = useState(false);
  const [progress,setProgress] = useState(0);
  const [existingMedia,setExistingMedia] = useState(editing?.media || []);
  const [removedMedia,setRemovedMedia] = useState<Project['media']>([]);
  const [files,setFiles] = useState<File[]>([]);
  const [coverImageChoice,setCoverImageChoice] = useState(editing?.coverImage || '');
  const [status,setStatus] = useState<ProjectStatus>(editing?.status || 'planned');
  const [publication,setPublication] = useState<Project['publicationStatus']>(editing?.publicationStatus || 'draft');
  const [category,setCategory] = useState(editing?.category || projectCategories[0]);
  const [message,setMessage] = useState('');
  const [videoUrls,setVideoUrls] = useState((editing?.videoUrls || []).join('\n'));
  const [featured,setFeatured] = useState(editing?.featured || false);

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMessage('');
    const form = new FormData(e.currentTarget);
    const title = String(form.get('title')||'').trim();
    if (!title) { setMessage('A project title is required.'); setBusy(false); return; }
    try {
      const base: Partial<Project> & {id?:string} = {
        ...(editing?{id:editing.id}:{}),
        title,
        slug: slugify(title),
        summary: String(form.get('summary')||'').trim(),
        story: String(form.get('story')||'').trim(),
        category,
        secondaryCategory: String(form.get('secondaryCategory')||'').trim(),
        leosticYear: String(form.get('leosticYear')||'2026/27').trim(),
        startDate: String(form.get('startDate')||''),
        endDate: String(form.get('endDate')||'') || undefined,
        location: String(form.get('location')||'').trim(),
        status,
        publicationStatus: editing ? (canPublish ? publication : (publication === 'draft' ? 'draft' : 'submitted')) : 'draft',
        coverImage: coverImageChoice,
        coverAlt: String(form.get('coverAlt')||title).trim(),
        media: existingMedia,
        videoUrls: videoUrls.split('\n').map(v=>v.trim()).filter(Boolean),
        metrics: String(form.get('metrics')||'').split('\n').map(row=>row.trim()).filter(Boolean).map(row=>{const [label,...val]=row.split('|');return {label:label.trim(),value:val.join('|').trim()};}).filter(m=>m.label&&m.value),
        partners: String(form.get('partners')||'').split(',').map(v=>v.trim()).filter(Boolean),
        projectChair: String(form.get('projectChair')||'').trim(),
        featured,
      };
      const id = await saveProject(base);
      const uploaded = files.length ? await uploadProjectMedia(id, files, (_index,percent)=>setProgress(percent)) : [];
      const allMedia = [...existingMedia, ...uploaded].map((m,i)=>({...m,order:i}));
      const firstImage = allMedia.find(m=>m.type==='image');
      const cover = coverImageChoice || firstImage?.url || '';
      await saveProject({id,media:allMedia,coverImage:cover,coverAlt:String(form.get('coverAlt')||title).trim()});
      for (const media of removedMedia) { try { await removeUploadedMedia(media.storagePath); } catch (removeError) { console.warn('Could not delete removed media file:', removeError); } }
      onSaved();
    } catch (err) {
      onError(err instanceof Error?err.message:'Could not save the project. Check Firebase configuration and security rules.');
    } finally { setBusy(false); }
  }

  return <form className="project-editor" onSubmit={submit}>
    <div className="editor-header"><div><button type="button" className="back-link dark-back" onClick={onCancel}>← Back to projects</button><span className="section-kicker">PROJECT EDITOR</span><h2>{editing?'Edit project':'Create a project'}</h2><p>Enter a verified project story. Fields marked with * are required.</p></div><span className="editor-step">01 / PROJECT STORY</span></div>
    <div className="editor-grid">
      <section className="editor-main">
        <div className="editor-card"><h3>Project identity</h3><label>Project name *<input name="title" required defaultValue={editing?.title || ''} placeholder="Enter the official project name"/></label><label>Short introduction *<textarea name="summary" rows={3} required defaultValue={editing?.summary || ''} placeholder="A short summary shown on project cards…"/></label><label>Full project story *<textarea name="story" rows={10} required defaultValue={editing?.story || ''} placeholder={'## Background\nDescribe the community need.\n\n## What we did\nExplain the activity and how it was delivered.\n\n## Impact\nAdd verified outcomes and reflections.'}/></label><small className="field-help">The story supports Markdown headings, paragraphs, lists and quotes. Do not include private personal or financial information.</small></div>
        <div className="editor-card"><h3>Project details</h3><div className="form-row"><label>Primary service category *<select value={category} onChange={e=>setCategory(e.target.value)}>{projectCategories.map(c=><option key={c}>{c}</option>)}</select></label><label>Secondary category<input name="secondaryCategory" defaultValue={editing?.secondaryCategory || ''} placeholder="Optional"/></label></div><div className="form-row"><label>Leostic year *<input name="leosticYear" defaultValue={editing?.leosticYear || '2026/27'} required/></label><label>Project status<select value={status} onChange={e=>setStatus(e.target.value as ProjectStatus)}><option value="planned">Planned</option><option value="upcoming">Upcoming</option><option value="ongoing">Ongoing</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></label></div><div className="form-row"><label>Start date *<input type="date" name="startDate" defaultValue={editing?.startDate || ''} required/></label><label>End date<input type="date" name="endDate" defaultValue={editing?.endDate || ''}/></label></div><label>Location *<input name="location" required defaultValue={editing?.location || ''} placeholder="Town / institution / location"/></label><div className="form-row"><label>Project chairperson<input name="projectChair" defaultValue={editing?.projectChair || ''}/></label><label>Partners (comma-separated)<input name="partners" defaultValue={editing?.partners.join(', ') || ''} placeholder="Partner organisations or clubs"/></label></div></div>
        <div className="editor-card"><h3>Impact and outcomes</h3><label>Verified metrics<textarea name="metrics" rows={4} defaultValue={editing?.metrics.map(m=>`${m.label} | ${m.value}`).join('\n') || ''} placeholder={'Beneficiaries | 120\nLeo volunteers | 18\nVolunteer hours | 64'} /></label><small className="field-help">One metric per line: Label | Value. Examples only; enter actual verified figures.</small></div>
        <div className="editor-card"><h3>Project media</h3><p>Upload approved photographs or short video files. Images: JPG, PNG or WebP (20 MB each). Videos: MP4, WebM or MOV (100 MB each).</p><label className="upload-drop"><UploadCloud size={27}/><b>Choose project photos and videos</b><span>Multiple files supported. Add captions and alt text after upload in the next edit pass.</span><input type="file" multiple accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime" onChange={e=>setFiles(Array.from(e.target.files||[]))}/></label>{files.length>0 && <div className="selected-files">{files.map(f=><span key={`${f.name}-${f.size}`}>{f.name}<small>{(f.size/1024/1024).toFixed(1)} MB</small></span>)}</div>}{existingMedia.length>0 && <div className="existing-media"><b>Saved media ({existingMedia.length})</b>{existingMedia.map((m,index)=><div className="media-edit-row" key={m.id}><div className="media-edit-thumb">{m.type==='image'?<img src={m.url} alt=""/>:<Video/>}</div><div className="media-edit-fields"><input aria-label="Photo or video caption" placeholder="Caption" value={m.caption} onChange={e=>setExistingMedia(prev=>prev.map(x=>x.id===m.id?{...x,caption:e.target.value}:x))}/><input aria-label="Image alt text" placeholder="Alt text / description" value={m.altText} onChange={e=>setExistingMedia(prev=>prev.map(x=>x.id===m.id?{...x,altText:e.target.value}:x))}/></div><div className="media-edit-actions"><button type="button" aria-label="Move media up" disabled={index===0} onClick={()=>setExistingMedia(prev=>{const next=[...prev];[next[index-1],next[index]]=[next[index],next[index-1]];return next;})}><ChevronUp size={14}/></button><button type="button" aria-label="Move media down" disabled={index===existingMedia.length-1} onClick={()=>setExistingMedia(prev=>{const next=[...prev];[next[index+1],next[index]]=[next[index],next[index+1]];return next;})}><ChevronDown size={14}/></button><button type="button" aria-label="Remove media" onClick={()=>{setRemovedMedia(prev=>[...prev,m]);setExistingMedia(prev=>prev.filter(x=>x.id!==m.id));if(coverImageChoice===m.url)setCoverImageChoice('');}}><X size={14}/></button></div></div>)}</div>}{busy && files.length>0 && <div className="upload-progress"><div style={{width:`${progress}%`}}/><span>Uploading… {progress}%</span></div>}</div>
        <div className="editor-card"><h3>Video links</h3><label>External video URLs (one per line)<textarea rows={3} value={videoUrls} onChange={e=>setVideoUrls(e.target.value)} placeholder="YouTube or Vimeo URL per line"/></label><small className="field-help">Use approved YouTube/Vimeo links for longer videos. Do not upload private or unconsented footage.</small></div>
      </section>
      <aside className="editor-aside"><div className="editor-card"><h3>Publication</h3><label>Publication status<select value={publication} onChange={e=>setPublication(e.target.value as Project['publicationStatus'])} disabled={!canPublish}><option value="draft">Draft</option><option value="submitted">Submitted for review</option><option value="published">Published</option><option value="archived">Archived</option></select></label>{!canPublish && <small className="field-help">Your role can submit content. A President, Secretary or Super Admin must publish it.</small>}<label className="toggle-line"><input type="checkbox" checked={featured} onChange={e=>setFeatured(e.target.checked)}/> Feature on homepage</label></div><div className="editor-card"><h3>Cover image</h3><p>The first uploaded image will be used as the cover if no cover has been set.</p>{editing?.coverImage && <img className="cover-preview" src={editing.coverImage} alt="Current project cover"/>}<label>Cover image<select value={coverImageChoice} onChange={e=>setCoverImageChoice(e.target.value)}><option value="">Use the first uploaded image</option>{existingMedia.filter(m=>m.type==='image').map(m=><option key={m.id} value={m.url}>{m.caption || m.altText || 'Project photo'}</option>)}</select></label><label>Image alt text<input name="coverAlt" defaultValue={editing?.coverAlt || ''} placeholder="Describe the cover photo for accessibility"/></label></div><div className="editor-card editor-note"><b>Before publishing</b><ul><li>Confirm the title and dates.</li><li>Check that every photo is approved for public use.</li><li>Use verified impact figures only.</li><li>Keep approval forms and financial records private.</li></ul></div></aside>
    </div>
    {message && <p className="form-error">{message}</p>}
    <div className="editor-actions"><button type="button" className="button button-outline-dark" onClick={onCancel}>Cancel</button><button type="submit" className="button button-dark" disabled={busy}>{busy?'Saving project…':publication==='published' && canPublish?'Save and publish':'Save project'} <Check size={16}/></button></div>
  </form>;
}
