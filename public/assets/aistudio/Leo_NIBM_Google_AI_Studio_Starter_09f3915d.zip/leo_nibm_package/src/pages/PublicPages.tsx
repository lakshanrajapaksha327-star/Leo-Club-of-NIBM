import { useMemo, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { ArrowDown, ArrowRight, ArrowUpRight, CalendarDays, CheckCircle2, Clock3, ExternalLink, HeartHandshake, Instagram, Mail, MapPin, Play, Sparkles, Users, Video, X } from 'lucide-react';
import { useClub } from '../context/ClubContext';
import { Reveal } from '../components/Reveal';
import ProjectCard from '../components/ProjectCard';
import EmptyState from '../components/EmptyState';
import { createMembershipEnquiry } from '../data/service';
import { firebaseReady } from '../lib/firebase';

const leosticYear = import.meta.env.VITE_LEOSTIC_YEAR || '2026/27';
const clubEmail = import.meta.env.VITE_CLUB_EMAIL || 'Confirm the official club email';
const categories = ['All', 'Children and Youth', 'Environment and Sustainability', 'Health and Nutrition', 'Peace and Culture', 'Sports and Recreation', 'Senior Citizens', 'Disability Support', 'Public Relations', 'Fundraising', 'Education and Literacy', 'Women Empowerment', 'Poverty and Community Development', 'Safety and Crime Prevention', 'Infrastructure', 'Research and Innovation', 'Drug Prevention', 'Animals and Wildlife', 'Fellowship and Community Engagement', 'Hunger and Food Security', 'Vision Care', 'Disaster Management'];

function PageIntro({ kicker, title, text }: { kicker: string; title: string; text: string }) {
  return <section className="page-intro"><div className="section-kicker">{kicker}</div><h1>{title}</h1><p>{text}</p></section>;
}

function SectionHeading({ kicker, title, text, link, to }: { kicker: string; title: string; text?: string; link?: string; to?: string }) {
  return <div className="section-heading"><div><span className="section-kicker">{kicker}</span><h2>{title}</h2>{text && <p>{text}</p>}</div>{link && to && <Link className="outline-link" to={to}>{link}<ArrowUpRight size={16}/></Link>}</div>;
}

export function HomePage() {
  const { projects, events, officers, loading } = useClub();
  const featured = projects.filter(p => p.featured).slice(0, 3);
  const latest = featured.length ? featured : projects.slice(0, 3);
  return <>
    <section className="hero-section">
      <div className="hero-ambient hero-ambient-one"/><div className="hero-ambient hero-ambient-two"/>
      <div className="hero-grid"/>
      <div className="hero-copy">
        <motion.div className="hero-kicker" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .1 }}><span className="live-dot"/> LEOISTIC YEAR {leosticYear} <i/> LEO DISTRICT 306 D7</motion.div>
        <motion.h1 initial={{ opacity: 0, y: 28 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .18 }}>Lead with <em>purpose.</em><br/>Serve with <em>heart.</em></motion.h1>
        <motion.p initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .32 }}>We are the Leo Club of NIBM — a community of young leaders turning ideas into action and service into lasting impact.</motion.p>
        <motion.div className="hero-actions" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .42 }}><Link className="button button-gold" to="/projects">Explore our projects <ArrowUpRight size={17}/></Link><Link className="button button-glass" to="/about">Discover our story <ArrowRight size={16}/></Link></motion.div>
        <div className="hero-footnote"><span>LEADERSHIP</span><span>EXPERIENCE</span><span>OPPORTUNITY</span></div>
      </div>
      <div className="hero-art" aria-label="Leo Club of NIBM identity artwork"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-seal"><img src="/assets/Leo_Club_of_NIBM_D7_latest.jpeg" alt="Leo Club of NIBM logo"/><span>WE SERVE</span></div><div className="hero-stamp">NIBM<br/><b>LEOS</b><small>306 D7 · SRI LANKA</small></div><div className="hero-glow"/></div>
      <a className="scroll-cue" href="#intro"><span>SCROLL TO EXPLORE</span><ArrowDown size={15}/></a>
    </section>

    <section className="intro-band section-pad" id="intro"><Reveal><div className="section-kicker">WHO WE ARE</div><h2>Young minds.<br/><em>Meaningful change.</em></h2></Reveal><Reveal delay={.12}><div className="intro-text"><p>Leoism is more than a club. It is an opportunity to lead, learn, connect and create positive change through community service.</p><Link className="text-link" to="/about">Get to know us <ArrowUpRight size={16}/></Link></div></Reveal></section>

    <section className="pillars-section section-pad"><SectionHeading kicker="THE LEO EXPERIENCE" title="Three letters. A world of possibility." text="The values that guide our journey as young leaders and community volunteers."/><div className="pillars-grid">{[
      { n:'01', title:'Leadership', body:'Step forward, take initiative and inspire people around you to make a difference.', symbol:'L' },
      { n:'02', title:'Experience', body:'Learn through real projects, collaboration, responsibility and shared moments.', symbol:'E' },
      { n:'03', title:'Opportunity', body:'Discover your strengths, build connections and turn your ideas into action.', symbol:'O' },
    ].map((item,i)=><Reveal key={item.n} delay={i*.1}><article className="pillar-card"><div className="pillar-top"><span>{item.n}</span><span className="pillar-symbol">{item.symbol}</span></div><h3>{item.title}</h3><p>{item.body}</p><span className="pillar-line"/></article></Reveal>)}</div></section>

    <section className="projects-preview section-pad"><SectionHeading kicker="OUR WORK IN ACTION" title="Stories that make a difference." text="Explore the projects, people and moments behind our service." link="View all projects" to="/projects"/>{loading ? <div className="loading-note">Loading published project stories…</div> : latest.length ? <div className="project-grid">{latest.map(p=><ProjectCard key={p.id} project={p}/>)}</div> : <EmptyState title="Project stories are being prepared" text="Approved NIBM project stories will appear here with their photographs, videos and impact details."/>}</section>

    <section className="impact-strip section-pad"><div className="impact-copy"><span className="section-kicker">OUR PROMISE</span><h2>Make every action<br/><em>count.</em></h2><p>We believe that meaningful change begins when people come together with empathy, energy and a willingness to serve.</p><Link className="button button-light" to="/join">Be part of the movement <ArrowUpRight size={16}/></Link></div><div className="impact-values"><div><span className="impact-icon"><HeartHandshake/></span><h3>Community first</h3><p>Listen, understand and respond to real needs.</p></div><div><span className="impact-icon"><Users/></span><h3>Stronger together</h3><p>Build friendships and partnerships through service.</p></div><div><span className="impact-icon"><Sparkles/></span><h3>Grow through action</h3><p>Turn experience into confidence and leadership.</p></div></div></section>

    <section className="split-preview section-pad"><div><span className="section-kicker">THE PEOPLE BEHIND THE PURPOSE</span><h2>One club.<br/><em>Many voices.</em></h2><p>Meet the members who lead, organise and contribute to the Leo Club of NIBM.</p><Link className="text-link" to="/team">Meet our team <ArrowUpRight size={16}/></Link></div><div className="split-photo"><div className="photo-placeholder"><span>ADD APPROVED NIBM CLUB PHOTOGRAPH</span><img src="/assets/Leo_Club_of_NIBM_D7_latest.jpeg" alt="Leo Club emblem"/></div><span className="photo-caption">LEO CLUB OF NIBM · SRI LANKA</span></div></section>

    <section className="events-preview section-pad"><SectionHeading kicker="WHAT'S HAPPENING" title="Stay in the loop." text="Club meetings, service activities and events will be published here." link="All events" to="/events"/>{events.length ? <div className="event-list">{events.slice(0,3).map(e=><article key={e.id} className="event-row"><div className="event-date"><strong>{new Date(e.date).getDate()}</strong><span>{new Date(e.date).toLocaleString('en',{month:'short'})}</span></div><div><h3>{e.title}</h3><p>{e.summary}</p></div><span className="event-status">{e.status}</span></article>)}</div> : <EmptyState title="No public events yet" text="Approved club events and registration details will be listed here."/>}</section>

    <section className="join-banner section-pad"><div><span className="section-kicker">YOUR JOURNEY STARTS HERE</span><h2>Have the heart<br/>to <em>make a difference?</em></h2><p>Find your place in a community that learns, leads and serves together.</p></div><Link className="button button-gold" to="/join">Join the Leo Club of NIBM <ArrowUpRight size={17}/></Link></section>
  </>;
}

export function AboutPage() {
  return <><PageIntro kicker="ABOUT THE CLUB" title="A place to lead, learn and serve." text="Discover the Leo movement, the values behind it and the role of the Leo Club of NIBM."/><section className="content-section section-pad"><div className="content-main"><span className="section-kicker">ABOUT LEOISM</span><h2>Leadership. Experience. Opportunity.</h2><p>Leo Clubs are youth-led service organisations connected to Lions Clubs International. They give young people opportunities to develop leadership skills, gain experience and serve their communities.</p><p>The Leo Club of NIBM is part of the Leo movement in Sri Lanka and the Maldives. Its local work, leadership and annual records should be presented here using information verified by the current club committee.</p><h3>Our place in the Leo movement</h3><div className="org-tree"><div>Lions Clubs International</div><i/><div>Leo Multiple District 306 · Sri Lanka & Maldives</div><i/><div>Leo District 306 D7</div><i/><div className="org-current">Leo Club of NIBM</div></div><h3>Our history</h3><p>The club's charter date, founding story, milestones and past committee records should be added after verification from the club's official records.</p></div><aside className="content-aside"><div className="aside-card"><span className="section-kicker">OUR THREE PILLARS</span><strong>LEADERSHIP</strong><strong>EXPERIENCE</strong><strong>OPPORTUNITY</strong></div><div className="aside-card aside-dark"><span className="section-kicker">OUR AFFILIATION</span><p>Leo District 306 D7</p><a href="https://www.leomd306.org/" target="_blank" rel="noreferrer">Leo Multiple District 306 <ExternalLink size={14}/></a></div></aside></section></>;
}

export function ProjectsPage() {
  const { projects, loading } = useClub();
  const [category,setCategory] = useState('All');
  const [status,setStatus] = useState('All');
  const [year,setYear] = useState('All');
  const [search,setSearch] = useState('');
  const years = Array.from(new Set(projects.map(p=>p.leosticYear))).sort().reverse();
  const filtered = useMemo(() => projects.filter(p => (category==='All' || p.category===category) && (status==='All' || p.status===status.toLowerCase()) && (year==='All' || p.leosticYear===year) && `${p.title} ${p.summary} ${p.location}`.toLowerCase().includes(search.toLowerCase())), [projects,category,status,year,search]);
  return <><PageIntro kicker="PROJECTS & IMPACT" title="Every project has a story." text="Explore the people, ideas and service behind the work of Leo Club of NIBM."/><section className="section-pad projects-page"><div className="project-tools"><div className="filter-chips">{categories.map(c=><button key={c} className={category===c?'filter-chip selected':'filter-chip'} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="project-search"><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search project stories…" aria-label="Search projects"/><select value={year} onChange={e=>setYear(e.target.value)} aria-label="Filter Leostic year"><option value="All">All years</option>{years.map(y=><option key={y}>{y}</option>)}</select><select value={status} onChange={e=>setStatus(e.target.value)} aria-label="Filter project status"><option>All</option><option>Upcoming</option><option>Ongoing</option><option>Completed</option></select></div></div>{loading ? <div className="loading-note">Loading projects…</div> : filtered.length ? <div className="project-grid">{filtered.map(p=><ProjectCard key={p.id} project={p}/>)}</div> : <EmptyState title="No matching project stories" text="When a project is approved and published by the club, it will appear here as a story with a cover photo, details and media gallery."/>}</section></>;
}

function getYoutubeEmbed(url: string) {
  try {
    const parsed = new URL(url);
    if (parsed.hostname.includes('youtu.be')) return `https://www.youtube-nocookie.com/embed/${parsed.pathname.slice(1)}`;
    if (parsed.hostname.includes('youtube.com')) return `https://www.youtube-nocookie.com/embed/${parsed.searchParams.get('v') || parsed.pathname.split('/').pop()}`;
    if (parsed.hostname.includes('vimeo.com')) return `https://player.vimeo.com/video/${parsed.pathname.split('/').pop()}`;
  } catch { return ''; }
  return '';
}

export function ProjectDetailPage() {
  const { slug } = useParams();
  const { projects, loading } = useClub();
  const project = projects.find(p => p.slug===slug);
  const [lightbox,setLightbox] = useState<string|null>(null);
  if (loading) return <div className="loading-page">Loading project story…</div>;
  if (!project) return <div className="section-pad"><EmptyState title="Project not found" text="This story may not be published yet or the link may have changed."/><Link className="text-link" to="/projects">Back to projects <ArrowRight size={15}/></Link></div>;
  const images = project.media.filter(m=>m.type==='image');
  const uploadedVideos = project.media.filter(m=>m.type==='video');
  const externalVideos = project.videoUrls;
  return <article className="project-story">
    <div className="story-hero">{project.coverImage && <img src={project.coverImage} alt={project.coverAlt || project.title}/>}<div className="story-hero-overlay"/><div className="story-hero-copy"><Link to="/projects" className="back-link">← All projects</Link><span className="section-kicker">{project.category} · {project.leosticYear}</span><h1>{project.title}</h1><p>{project.summary}</p><div className="story-meta"><span><CalendarDays size={15}/>{project.startDate}</span><span><MapPin size={15}/>{project.location}</span><span><Clock3 size={15}/>{project.status}</span></div></div></div>
    <div className="story-layout"><div className="story-content"><span className="section-kicker">THE STORY</span><div className="markdown-body"><ReactMarkdown>{project.story || project.summary}</ReactMarkdown></div>{project.metrics.length>0 && <section className="story-impact"><span className="section-kicker">PROJECT IMPACT</span><div className="metric-grid">{project.metrics.map((m,i)=><div key={i}><strong>{m.value}</strong><span>{m.label}</span></div>)}</div></section>}{images.length>0 && <section className="story-gallery"><span className="section-kicker">MOMENTS FROM THE PROJECT</span><div className="story-photo-grid">{images.map(m=><button key={m.id} onClick={()=>setLightbox(m.url)} className="story-photo"><img src={m.url} alt={m.altText || m.caption || project.title}/>{m.caption && <span>{m.caption}</span>}</button>)}</div></section>}{(uploadedVideos.length>0 || externalVideos.length>0) && <section className="story-videos"><span className="section-kicker">WATCH THE PROJECT</span><div className="video-grid">{uploadedVideos.map((m,i)=><video key={m.id} controls preload="metadata" src={m.url} aria-label={m.altText || `${project.title} video ${i+1}`}/>)}{externalVideos.map((url,i)=>{const embed=getYoutubeEmbed(url);return embed ? <iframe key={i} src={embed} title={`${project.title} video ${i+1}`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen/> : <a key={i} className="video-link" href={url} target="_blank" rel="noreferrer"><Video/>Open project video <ExternalLink size={14}/></a>;})}</div></section>}</div><aside className="story-aside"><div className="story-facts"><span className="section-kicker">PROJECT DETAILS</span><div><small>Project status</small><b>{project.status}</b></div><div><small>Project location</small><b>{project.location}</b></div><div><small>Leostic year</small><b>{project.leosticYear}</b></div>{project.projectChair && <div><small>Project chairperson</small><b>{project.projectChair}</b></div>}{project.partners.length>0 && <div><small>Partners</small><b>{project.partners.join(', ')}</b></div>}</div><Link to="/projects" className="outline-link">Discover more projects <ArrowUpRight size={15}/></Link></aside></div>
    {lightbox && <div className="lightbox" onClick={()=>setLightbox(null)} role="presentation"><button aria-label="Close image" onClick={()=>setLightbox(null)}><X/></button><img src={lightbox} alt="Expanded project photograph"/></div>}
  </article>;
}

export function EventsPage() {
  const { events, loading } = useClub();
  const sorted = [...events].sort((a,b)=>a.date.localeCompare(b.date));
  return <><PageIntro kicker="CLUB CALENDAR" title="Moments that bring us together." text="Explore upcoming club meetings, service activities, leadership events and shared experiences."/><section className="section-pad">{loading ? <div className="loading-note">Loading events…</div> : sorted.length ? <div className="event-list">{sorted.map(e=><article key={e.id} className="event-row"><div className="event-date"><strong>{new Date(e.date).getDate()}</strong><span>{new Date(e.date).toLocaleString('en',{month:'short'})}</span></div><div><h3>{e.title}</h3><p>{e.summary}</p><small><MapPin size={13}/>{e.location}</small></div><span className="event-status">{e.status}</span></article>)}</div> : <EmptyState title="The calendar is being updated" text="The current committee can publish approved events from the admin dashboard."/>}</section></>;
}

export function TeamPage() {
  const { officers, loading } = useClub();
  const grouped = useMemo(()=>officers.reduce<Record<string, typeof officers>>((acc,o)=>{(acc[o.position] ||= []).push(o);return acc;},{}),[officers]);
  return <><PageIntro kicker="OUR PEOPLE" title="The people behind the purpose." text="Meet the team serving, leading and supporting the Leo Club of NIBM."/><section className="section-pad">{loading ? <div className="loading-note">Loading team…</div> : officers.length ? <div className="officer-grid">{officers.map(o=><article key={o.id} className="officer-card">{o.photoUrl ? <img src={o.photoUrl} alt={o.name}/> : <div className="officer-placeholder">NIBM<br/>LEO</div>}<div><span className="section-kicker">{o.leosticYear}</span><h3>{o.name}</h3><p>{o.position}</p>{o.biography && <small>{o.biography}</small>}</div></article>)}</div> : <EmptyState title="Meet the 2026/27 team soon" text="The confirmed current executive committee and approved member profiles will appear here."/>}</section></>;
}

export function GalleryPage() {
  const { projects } = useClub();
  const items = projects.flatMap(p=>p.media.filter(m=>m.type==='image').map(m=>({...m, projectTitle:p.title, slug:p.slug})));
  const [selected,setSelected] = useState<string|null>(null);
  return <><PageIntro kicker="MEMORIES & MOMENTS" title="A gallery of service and friendship." text="Photographs from the projects, events and experiences that shape our club."/><section className="section-pad">{items.length ? <div className="gallery-grid">{items.map(m=><button key={m.id} onClick={()=>setSelected(m.url)}><img src={m.url} alt={m.altText || m.caption}/><span>{m.projectTitle}</span></button>)}</div> : <EmptyState title="The gallery is waiting for its first stories" text="When project galleries and event photographs are uploaded and approved, they will appear here automatically."/>}</section>{selected && <div className="lightbox" onClick={()=>setSelected(null)}><button onClick={()=>setSelected(null)}><X/></button><img src={selected} alt="Gallery photograph"/></div>}</>;
}

export function PublicationsPage() {
  const { publications, loading } = useClub();
  return <><PageIntro kicker="PUBLICATIONS & ARCHIVES" title="Stories worth keeping." text="Explore newsletters, annual reports, club magazines and selected publications from our journey."/><section className="section-pad">{loading ? <div className="loading-note">Loading publications…</div> : publications.length ? <div className="publication-grid">{publications.map(p=><article key={p.id} className="publication-card">{p.coverUrl ? <img src={p.coverUrl} alt={`${p.title} cover`}/> : <div className="publication-placeholder">NIBM<br/><b>LEO</b></div>}<div><span className="section-kicker">{p.leosticYear} · {p.date}</span><h3>{p.title}</h3><p>{p.description}</p>{p.pdfUrl && <a className="text-link" href={p.pdfUrl} target="_blank" rel="noreferrer">Read publication <ArrowUpRight size={15}/></a>}</div></article>)}</div> : <EmptyState title="Publications archive coming soon" text="Approved UNSTOPPABLE editions, newsletters and annual reports will be added by the media team."/>}</section></>;
}

export function JoinPage() {
  const [busy,setBusy] = useState(false); const [success,setSuccess] = useState(false); const [error,setError] = useState('');
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError(''); setSuccess(false);
    const form = new FormData(e.currentTarget); const data: Record<string,string> = {};
    ['fullName','email','programme','batch','reason'].forEach(k=>data[k]=String(form.get(k)||'').trim());
    if (!data.fullName || !data.email || !data.reason) { setError('Please complete your name, email and reason for joining.'); setBusy(false); return; }
    if (!firebaseReady) { setError('Membership submissions are not connected yet. Complete the Firebase setup before accepting real applications.'); setBusy(false); return; }
    try { await createMembershipEnquiry(data); setSuccess(true); e.currentTarget.reset(); }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not submit your enquiry. Please try again.'); }
    finally { setBusy(false); }
  }
  return <><PageIntro kicker="JOIN OUR COMMUNITY" title="Your story can start here." text="Become part of a community that builds leadership through experience and serves with purpose."/><section className="join-layout section-pad"><div className="join-copy"><span className="section-kicker">WHY BECOME A LEO?</span><h2>Learn by doing.<br/><em>Grow by serving.</em></h2><p>Be part of service projects, leadership opportunities, teamwork and friendships that extend beyond campus.</p><div className="join-benefit"><CheckCircle2/><div><b>Make a difference</b><span>Contribute to meaningful community initiatives.</span></div></div><div className="join-benefit"><CheckCircle2/><div><b>Build real skills</b><span>Develop communication, planning and teamwork.</span></div></div><div className="join-benefit"><CheckCircle2/><div><b>Find your people</b><span>Connect with a supportive community of student leaders.</span></div></div></div><form className="join-form" onSubmit={submit}><span className="section-kicker">MEMBERSHIP ENQUIRY</span><h2>Tell us about yourself.</h2><label>Full name *<input name="fullName" required placeholder="Your full name"/></label><label>Email address *<input type="email" name="email" required placeholder="you@example.com"/></label><div className="form-row"><label>Study programme<input name="programme" placeholder="e.g. Software Engineering"/></label><label>Batch / year<input name="batch" placeholder="e.g. 2026 intake"/></label></div><label>Why would you like to join? *<textarea name="reason" rows={4} required placeholder="Tell us what interests you about Leoism…"/></label><p className="privacy-note">Your details will be used only for membership enquiries and must be accessible only to authorised club administrators.</p>{error && <p className="form-error">{error}</p>}{success && <p className="form-success">Thank you. Your enquiry has been received.</p>}<button className="button button-dark" type="submit" disabled={busy}>{busy?'Submitting…':'Send membership enquiry'} <ArrowUpRight size={16}/></button></form></section></>;
}

export function ContactPage() {
  return <><PageIntro kicker="GET IN TOUCH" title="Let's start a conversation." text="Have a question about the club, our projects or membership? Reach out through the official channels."/><section className="contact-cards section-pad"><article><span><Mail/></span><h3>Email the club</h3><p>{clubEmail}</p><small>Confirm and replace the placeholder with the approved public email address.</small></article><article><span><Instagram/></span><h3>Follow our journey</h3><p>Official social media links will be added after the committee confirms the active accounts.</p></article><article><span><MapPin/></span><h3>Our affiliation</h3><p>National Institute of Business Management (NIBM), Sri Lanka.</p></article></section><div className="contact-district section-pad"><div><span className="section-kicker">CONNECTED TO THE MOVEMENT</span><h2>Part of something bigger.</h2><p>Explore the Leo movement at district, multiple-district and international level.</p></div><div className="district-links"><a href="https://www.leomd306.org/" target="_blank" rel="noreferrer">Leo Multiple District 306 <ArrowUpRight/></a><a href="https://www.lionsclubs.org/en/discover-our-clubs/about-leos" target="_blank" rel="noreferrer">About Leos · Lions International <ArrowUpRight/></a></div></div></>;
}

export function NotFoundPage() { return <div className="section-pad"><PageIntro kicker="404" title="This page wandered off." text="The page you are looking for does not exist or may have moved."/><Link className="button button-dark" to="/">Return home <ArrowRight size={16}/></Link></div>; }


export function AwardsPage() {
  return <><PageIntro kicker="RECOGNITION & MILESTONES" title="Celebrating service, not just awards." text="A verified archive of club, project and individual recognitions across Leostic years."/><section className="section-pad"><EmptyState title="Awards archive awaiting verified records" text="The club media team can add award titles, category, year, recipient and approved certificate or event photographs through the content dashboard."/></section></>;
}
