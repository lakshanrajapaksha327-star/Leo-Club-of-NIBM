export type ProjectStatus = 'planned' | 'upcoming' | 'ongoing' | 'completed' | 'cancelled';
export type PublicationStatus = 'draft' | 'submitted' | 'published' | 'archived';
export type MediaType = 'image' | 'video';

export interface ProjectMedia {
  id: string;
  url: string;
  storagePath?: string;
  type: MediaType;
  caption: string;
  altText: string;
  order: number;
}

export interface ProjectMetric {
  label: string;
  value: string;
}

export interface Project {
  id: string;
  title: string;
  slug: string;
  summary: string;
  story: string;
  category: string;
  secondaryCategory?: string;
  leosticYear: string;
  startDate: string;
  endDate?: string;
  location: string;
  status: ProjectStatus;
  publicationStatus: PublicationStatus;
  coverImage: string;
  coverAlt: string;
  media: ProjectMedia[];
  videoUrls: string[];
  metrics: ProjectMetric[];
  partners: string[];
  projectChair?: string;
  featured: boolean;
  createdAt?: number;
  updatedAt?: number;
}

export interface ClubEvent {
  id: string;
  title: string;
  summary: string;
  date: string;
  location: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  posterUrl?: string;
  registrationUrl?: string;
}

export interface Officer {
  id: string;
  name: string;
  position: string;
  leosticYear: string;
  biography?: string;
  photoUrl?: string;
  displayOrder: number;
}

export interface Publication {
  id: string;
  title: string;
  description: string;
  date: string;
  coverUrl?: string;
  pdfUrl?: string;
  leosticYear: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  role: 'superAdmin' | 'president' | 'secretary' | 'projectEditor' | 'mediaEditor' | 'viewer';
  active: boolean;
}
