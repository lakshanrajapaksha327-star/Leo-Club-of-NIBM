import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// If Google AI Studio generated Firebase integration for this app, ask the agent
// to reuse its generated Firebase app/config here instead of creating a second app.
const env = import.meta.env;
const config = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: env.VITE_FIREBASE_APP_ID,
};

export const firebaseReady = Object.values(config).every((value) => typeof value === 'string' && value.length > 0 && !value.startsWith('replace-'));
export const firebaseApp = firebaseReady ? (getApps().length ? getApp() : initializeApp(config)) : null;
export const auth = firebaseApp ? getAuth(firebaseApp) : null;
export const db = firebaseApp ? getFirestore(firebaseApp) : null;
export const storage = firebaseApp ? getStorage(firebaseApp) : null;
export const googleProvider = new GoogleAuthProvider();

export function requireFirebase() {
  if (!auth || !db || !storage) {
    throw new Error('Firebase is not configured. Enable Firebase in Google AI Studio and connect Authentication, Firestore and Cloud Storage.');
  }
  return { auth, db, storage };
}
