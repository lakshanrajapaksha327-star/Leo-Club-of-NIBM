import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { ClubEvent, Officer, Project, Publication } from '../types';
import { firebaseReady } from '../lib/firebase';
import { demoEvents, demoOfficers, demoProjects, demoPublications } from '../data/demo';
import { getPublicEvents, getPublicOfficers, getPublicProjects, getPublications } from '../data/service';

interface ClubContextValue {
  projects: Project[];
  events: ClubEvent[];
  officers: Officer[];
  publications: Publication[];
  loading: boolean;
  refresh: () => Promise<void>;
  isDemo: boolean;
}

const ClubContext = createContext<ClubContextValue | null>(null);

export function ClubProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>(demoProjects);
  const [events, setEvents] = useState<ClubEvent[]>(demoEvents);
  const [officers, setOfficers] = useState<Officer[]>(demoOfficers);
  const [publications, setPublications] = useState<Publication[]>(demoPublications);
  const [loading, setLoading] = useState(firebaseReady);

  const refresh = useCallback(async () => {
    if (!firebaseReady) {
      setProjects(demoProjects); setEvents(demoEvents); setOfficers(demoOfficers); setPublications(demoPublications);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const [p, e, o, pub] = await Promise.all([
        getPublicProjects(), getPublicEvents(), getPublicOfficers(), getPublications(),
      ]);
      setProjects(p); setEvents(e); setOfficers(o); setPublications(pub);
    } catch (error) {
      console.error('Could not load public club content:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const value = useMemo(() => ({ projects, events, officers, publications, loading, refresh, isDemo: !firebaseReady }), [projects, events, officers, publications, loading, refresh]);
  return <ClubContext.Provider value={value}>{children}</ClubContext.Provider>;
}

export function useClub() {
  const context = useContext(ClubContext);
  if (!context) throw new Error('useClub must be used inside ClubProvider');
  return context;
}
