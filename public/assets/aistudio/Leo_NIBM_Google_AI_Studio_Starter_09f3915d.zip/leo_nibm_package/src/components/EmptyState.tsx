import { FolderOpen } from 'lucide-react';
export default function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><span className="empty-icon"><FolderOpen size={25}/></span><h3>{title}</h3><p>{text}</p></div>;
}
