import { ArrowUpRight, CalendarDays, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Project } from '../types';

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <article className="project-card">
      <Link to={`/projects/${project.slug}`} className="project-card-image">
        {project.coverImage ? <img src={project.coverImage} alt={project.coverAlt || project.title} loading="lazy"/> : <div className="image-placeholder"><span>LEO / NIBM</span></div>}
        <span className="project-status">{project.status}</span>
        <span className="card-arrow"><ArrowUpRight size={19}/></span>
      </Link>
      <div className="project-card-body">
        <div className="eyebrow-row"><span>{project.category}</span><span>{project.leosticYear}</span></div>
        <h3><Link to={`/projects/${project.slug}`}>{project.title}</Link></h3>
        <p>{project.summary}</p>
        <div className="project-meta"><span><CalendarDays size={14}/>{project.startDate || 'Date to be confirmed'}</span><span><MapPin size={14}/>{project.location || 'NIBM / Sri Lanka'}</span></div>
        <Link className="text-link" to={`/projects/${project.slug}`}>Explore project <ArrowUpRight size={15}/></Link>
      </div>
    </article>
  );
}
