import { useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { ArrowUpRight, Instagram, Facebook, Menu, X, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import logo from '../../assets/Leo_Club_of_NIBM_D7_latest.jpeg';

const links = [
  ['About', '/about'], ['Projects', '/projects'], ['Events', '/events'],
  ['Our Team', '/team'], ['Gallery', '/gallery'], ['Awards', '/awards'], ['Publications', '/publications'], ['Contact', '/contact'],
];

export default function Layout() {
  const [open, setOpen] = useState(false);
  return (
    <div className="site-shell">
      <div className="topline"><span>LEOISTIC YEAR 2026 / 2027</span><span className="topline-dot"/> <span>LEO DISTRICT 306 D7 · SRI LANKA</span></div>
      <header className="site-header">
        <Link to="/" className="brand" aria-label="Leo Club of NIBM home" onClick={() => setOpen(false)}>
          <img src={logo} alt="Leo Club of NIBM logo" />
          <span><strong>LEO CLUB</strong><small>OF NIBM</small></span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          {links.map(([label, to]) => <NavLink key={to} to={to} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}
        </nav>
        <div className="header-actions">
          <Link className="header-join" to="/join">Join the Club <ArrowUpRight size={15}/></Link>
          <Link className="admin-icon" to="/admin" aria-label="Admin login"><ShieldCheck size={18}/></Link>
          <button className="mobile-toggle" onClick={() => setOpen(v => !v)} aria-label="Toggle menu">{open ? <X/> : <Menu/>}</button>
        </div>
      </header>
      <AnimatePresence>
        {open && <motion.nav className="mobile-nav" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
          {links.map(([label, to]) => <NavLink key={to} to={to} onClick={() => setOpen(false)}>{label}</NavLink>)}
          <Link to="/join" onClick={() => setOpen(false)}>Join the Club <ArrowUpRight size={15}/></Link>
        </motion.nav>}
      </AnimatePresence>
      <main><Outlet/></main>
      <footer className="site-footer">
        <div className="footer-top">
          <div className="footer-brand"><img src={logo} alt="Leo Club of NIBM"/><div><strong>LEO CLUB OF NIBM</strong><span>Leadership · Experience · Opportunity</span></div></div>
          <p>Young leaders. Meaningful service. A stronger community.</p>
          <Link to="/join" className="footer-cta">Become a Leo <ArrowUpRight size={16}/></Link>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Leo Club of NIBM. All rights reserved.</span>
          <span>Leo District 306 D7 · Leo Multiple District 306</span>
          <div className="footer-social"><a href="#social" aria-label="Facebook"><Facebook size={16}/></a><a href="#social" aria-label="Instagram"><Instagram size={16}/></a></div>
        </div>
      </footer>
    </div>
  );
}
