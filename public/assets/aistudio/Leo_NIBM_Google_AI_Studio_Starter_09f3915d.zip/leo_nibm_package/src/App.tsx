import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import AdminPage from './pages/AdminPage';
import {
  AboutPage, AwardsPage, ContactPage, EventsPage, GalleryPage, HomePage, JoinPage,
  NotFoundPage, ProjectDetailPage, ProjectsPage, PublicationsPage, TeamPage,
} from './pages/PublicPages';

export default function App() {
  return <Routes>
    <Route element={<Layout/>}>
      <Route index element={<HomePage/>}/>
      <Route path="about" element={<AboutPage/>}/>
      <Route path="projects" element={<ProjectsPage/>}/>
      <Route path="projects/:slug" element={<ProjectDetailPage/>}/>
      <Route path="events" element={<EventsPage/>}/>
      <Route path="team" element={<TeamPage/>}/>
      <Route path="gallery" element={<GalleryPage/>}/>
      <Route path="publications" element={<PublicationsPage/>}/>
      <Route path="awards" element={<AwardsPage/>}/>
      <Route path="join" element={<JoinPage/>}/>
      <Route path="contact" element={<ContactPage/>}/>
      <Route path="*" element={<NotFoundPage/>}/>
    </Route>
    <Route path="admin" element={<AdminPage/>}/>
  </Routes>;
}
