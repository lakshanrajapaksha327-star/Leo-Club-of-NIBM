import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { ClubProvider } from './context/ClubContext';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <ClubProvider>
        <App />
      </ClubProvider>
    </BrowserRouter>
  </React.StrictMode>,
);
