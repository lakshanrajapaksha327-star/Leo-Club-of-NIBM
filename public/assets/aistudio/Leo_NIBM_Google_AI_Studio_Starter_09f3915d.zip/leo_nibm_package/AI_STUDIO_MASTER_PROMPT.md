# Google AI Studio - Master Build Prompt

Paste this into **Google AI Studio > Build mode** and select **Web app**. Do not select Android.

---

Build a polished, production-minded, responsive official website and content-management platform for **Leo Club of NIBM**, National Institute of Business Management (NIBM), Sri Lanka.

## 1. Reference websites and design intent

Use these references for visual and interaction direction:

1. SLIIT Leo reference: https://sliitleo.org/ProjectMap
   - Use this as the main reference for the overall site interface: navigation, page transitions, motion language, polished layout, interactive details, section composition, responsive behaviour, visual hierarchy and professional finish.
   - IMPORTANT: Do NOT reproduce the Project Map page or any map interface. Do not create a map, map markers, pins, map filters, geographic project pins, Google Maps, Leaflet, Mapbox or MapLibre. The map is explicitly excluded.
   - Apply the visual quality and overall interface language to the rest of the NIBM website. Use the supplied NIBM logos and D7 brand assets, not SLIIT logos, text, photos, fonts files or copyrighted assets.
   - SLIIT pages that may be used as secondary content/interaction references include its brand resources directory, club awards archive and structured navigation.

2. Kolonnawa Leos reference: https://kolonnawaleos.lk/witness-december-2025/
   - This URL is a Witness newsletter/publication page. Treat it as a publication/long-form editorial presentation reference, not a project map.
   - For the actual project presentation model, use the conventional editorial project listing and detail-story pattern demonstrated by the same site's Projects archive and individual project article pages:
     https://kolonnawaleos.lk/projects/
     https://kolonnawaleos.lk/paw-patrol-bruno-rescue-street-dog-sri-lanka/
   - Create a normal project archive with visual project cards. Clicking a card opens a full project story page with a cover image, story sections, project facts, impact numbers, photo gallery, embedded videos and related projects.
   - The user must be able to upload project photos/videos from the admin dashboard. Do not use a map for projects.

Before writing components, inspect the live SLIIT reference in a browser if browsing is available. Make a short visual inventory of the site's actual header, navigation, logo placement, typography, hero/first viewport, page background, colour use, content width, cards, buttons, hover states, scroll reveals, page transitions, footer and mobile menu. Use that inventory to keep the overall NIBM interface visually consistent with the reference across every public page. Do not invent a generic design before checking the reference.

The SLIIT ProjectMap route may be JavaScript-rendered and automated text extraction may not reveal its interface. If you cannot inspect the visible UI, ask the user to attach screenshots or screen recordings of: (1) top of page with header/navigation, (2) first full viewport, (3) one mid-page section, (4) card/list interactions, (5) footer, and (6) mobile view. Use these as visual references. Do not claim pixel-perfect reproduction without visual evidence. Build an original NIBM site inspired by its quality and motion, not a copy of its source code, text, photos, logo or identity.

## 2. Organisation and truthful content

- Public name: Leo Club of NIBM.
- Institution: National Institute of Business Management (NIBM), Sri Lanka.
- Organisational affiliation: Leo District 306 D7; Leo Multiple District 306 (Sri Lanka & Maldives); Lions Clubs International.
- Leostic year for the current site build: 2026/27. Make this editable in site settings and preserve previous years.
- Leo identity: Leadership, Experience, Opportunity.
- Use the original NIBM Leo logo and NIBM logo supplied in the project assets.
- Do not invent a charter date, mission, vision, current committee, member count, projects, achievements, partners, impact statistics, address, telephone number or social handle. Make unverified details editable placeholders or omit them until confirmed by the club.
- Use genuine club photos uploaded by administrators. Never present stock photos or sample data as actual NIBM projects.
- Use the 2026/27 D7 branding resources supplied by the user as a secondary identity reference: Plum #7A184D, Gold #E8AF25 to #F3D754, Purple #832D90, Indigo #3C2399; Montserrat for headings and Poppins for body. Apply these in a way that feels consistent with the SLIIT reference's visual system while keeping NIBM/Leo brand assets recognisable. Do not distort logos or create unofficial logo lockups. Confirm exact approved logo lockup with D7 before publishing official campaign artwork.

## 3. Required visual design

Create an elegant, premium, youthful and polished interface. Avoid a basic Bootstrap template or generic dashboard look.

- Responsive desktop, tablet and mobile layouts.
- High-quality hero section with strong typography, a subtle brand graphic/orbital element, dark premium surface and warm gold/plum accents.
- Sticky translucent navigation with smooth active states and a mobile menu.
- Sophisticated page transitions and scroll-reveal animation using Framer Motion (or equivalent already installed).
- Subtle hover interactions on cards, images, buttons and navigation.
- Smooth anchor scrolling and clear visual hierarchy.
- Consistent spacing, typography, border radius, shadows and colour tokens.
- Accessible keyboard navigation, visible focus states, descriptive image alt text and reduced-motion support.
- Avoid excessive animation, huge loading effects or motion that harms accessibility/performance.
- Use no map components anywhere.

## 4. Public pages

Build these working pages and navigation links:

1. Home
2. About the Club / Leoism
3. Projects
4. Individual Project Detail (dynamic route)
5. Events and Calendar
6. Our Team / Executive Committee
7. Gallery
8. Publications / Newsletters / Annual Reports
9. Awards and Achievements
10. Join Us / Membership Enquiry
11. Contact
12. Admin Login / Admin Dashboard

### Homepage sections
- Hero headline and concise introduction.
- Explore Projects and Join the Club CTAs.
- Leadership, Experience and Opportunity pillars.
- Latest or featured projects (loaded from the database).
- Verified impact metrics only; if not provided, hide the metric or show an honest empty state. Never invent counters.
- Upcoming events.
- Current committee preview.
- Recent gallery images.
- Publications/news highlights.
- District and international affiliation links.
- Footer with verified official contact/social links.

### About page
Explain Leoism and the club's verified identity. Show the Lions -> Leo Multiple District 306 -> Leo District 306 D7 -> Leo Club of NIBM relationship. Keep club history, charter date, mission and vision editable and unpublished until verified.

### Projects archive (NO MAP)
- Editorial project cards with real cover photos, project title, category, year, date, location, status and short summary.
- Search by title/summary.
- Filters by Leostic year, service category and activity status.
- Pagination or load-more for many projects.
- Featured project area.
- Good empty state when no approved public projects exist.
- Only show projects with publicationStatus = published.

### Individual project story page
- Large cover image and title.
- Summary, project category, Leostic year, dates and location.
- Markdown or rich-text story sections: Background, Need, Objectives, What We Did, Outcomes, Reflection/Next Steps.
- Verified impact metric blocks.
- Organising team and partners (approved names only).
- Photo gallery with lightbox, captions and alt text.
- Video embed area for YouTube/Vimeo and uploaded video files.
- Public project documents when explicitly approved.
- Related projects and share links.
- No map, pin, coordinates or route section.

## 5. Core project manager - must work end-to-end

This is the highest-priority admin feature. A club editor must be able to add a new project without changing code.

Create a secure Admin Dashboard > Projects > Add Project form with:
- Official project name.
- URL slug generated from title but editable if needed.
- Short summary.
- Full story/rich text or Markdown.
- Primary and optional secondary service category.
- Leostic year.
- Start date and end date.
- Location as plain text only (no map).
- Activity status: planned, upcoming, ongoing, completed, cancelled.
- Publication status: draft, submitted, published, archived.
- Cover image and cover alt text.
- Multiple image uploads with preview, caption, alt text, reordering, removing and cover-image selection.
- Multiple video uploads with sensible limits and/or YouTube/Vimeo URLs.
- Impact metrics (label + verified value).
- Project chairperson and approved organisers.
- Partner organisations/clubs.
- Public reports/certificates (only if approved).
- Private approval forms, invoices or internal records in a private storage area, never public URLs.
- Featured-on-homepage switch.
- Save draft, submit for review, approve/publish, edit, unpublish and archive.
- Upload progress, cancel/error feedback, file validation and image optimisation.

Media constraints for initial implementation:
- Images: JPG, PNG, WebP; maximum 20 MB each.
- Videos: MP4, WebM or MOV; maximum 100 MB each. Recommend YouTube/Vimeo embeds for larger videos to control hosting costs.
- Never upload private member records, invoices or approval documents into public-media.
- Ask for consent and check permissions before publishing photos of children or vulnerable people.

Project content must be database-driven. Do not hardcode projects in React components. An administrator creates a project record; the public project card and individual story page are generated from that record.

## 6. Other admin modules

Use role-based access and build create/edit/archive flows for:
- Events and event calendar.
- Current and previous-year committee members.
- Gallery albums and photo collections.
- News and articles.
- Publications (PDF/newsletter cover, issue, date, year, public PDF link).
- Awards and achievements by Leostic year.
- Club settings (logo, annual theme, email, social links, current Leostic year).
- Membership enquiries.

Preserve historic Leostic years. When a new committee takes over, archive the old year; do not overwrite or delete previous records.

## 7. Firebase backend for Google AI Studio

This is a web app. Use Google AI Studio's Firebase integration for Cloud Firestore and Google Authentication. When AI Studio displays the Firebase setup card, enable Firebase and select an appropriate Asia database location; Firestore database location cannot be changed later. `asia-south1` (Mumbai) is an available regional Firestore location; confirm availability in the setup UI before choosing.

Collections:
- users
- projects
- events
- officers
- galleries
- news
- publications
- achievements
- membershipEnquiries
- siteSettings
- auditLogs

Use Cloud Storage for Firebase for project images/videos and approved documents. It is a separate setup step. Current Firebase documentation says Cloud Storage for Firebase requires the Blaze pay-as-you-go plan to provision/use a default bucket. Explain this to the owner before enabling it; usage may have no-cost quotas but billing is still required. Provide file limits and usage guidance. Do not silently enable billing.

Use Firebase Authentication with Google sign-in for admins. Do not expose Firebase Admin SDK credentials or service account keys to the browser. Do not allow a user to assign their own admin role. The first Super Admin role is manually granted by the project owner in Firestore Console after sign-in. All subsequent role changes must be performed by an authorised Super Admin (preferably through a secure server-side function).

Required roles:
- superAdmin
- president
- secretary
- projectEditor
- mediaEditor
- viewer

Only President, Secretary and Super Admin can publish content. Project editors can create and submit drafts. Visitors can read published content only. Membership submissions are create-only for the public; read access is restricted to authorised staff.

Use and review Firestore/Storage security rules. Never use allow read, write: if true for the whole database or bucket. Never put secrets in client-side environment variables.

## 8. Technical constraints for Google AI Studio

- Build a WEB APP, not a native Android app.
- Use the React + TypeScript frontend generated by Google AI Studio Build Mode.
- Use the Node.js server runtime only for server-side tasks and privileged actions.
- Reuse the Firebase config and files that AI Studio creates. Do not initialise Firebase twice.
- Use the package dependencies already present if compatible. Install only needed packages.
- Use React Router for page routes.
- Use Framer Motion for motion and lucide-react for icons.
- Keep components small and organised; do not put the entire website in one component.
- Do not replace working code wholesale when making a small fix.
- Do not create an unrelated game, map or mobile app.
- Avoid hard-coded credentials, fake login, simulated uploads or localStorage as a substitute for persistent production storage.
- Do not claim the project is connected to Firebase until the connection is tested.
- Add loading, empty, success and error states.
- Test all pages and flows before saying a feature works.

## 9. Definition of done

Do not call the website complete until all of the following pass:
- All routes render and navigation works.
- The website is responsive on 360px mobile, tablet and desktop.
- No project map or map library is present.
- Admin sign-in works with the approved Google account.
- Unapproved users cannot access admin content.
- Project Editor can create a draft, upload multiple images, attach video URLs/files, edit and submit.
- President/Super Admin can review and publish.
- Only published projects appear publicly.
- Project cards link to their own dynamic detail pages.
- Gallery images open in a lightbox and have captions/alt text.
- Membership enquiry is stored privately and not publicly readable.
- Storage and Firestore security rules are reviewed and tested.
- No fake statistics, fake officers, fake projects or placeholder email/social links appear as real content.
- No console errors, TypeScript errors or broken image paths.
- Deploy only after the owner reviews expected Firebase/Cloud Storage/Cloud Run charges and domain details.

Start by building the public website UI and routes using honest empty states and the supplied NIBM logos. Then integrate Firebase. Then complete the project CMS. Do not skip the project upload workflow.
