# SLIIT visual reference screenshot checklist

The supplied SLIIT reference URL is https://sliitleo.org/ProjectMap. The route may render through JavaScript, and a text-only page reader may not expose the actual visual design. If Google AI Studio cannot inspect the visible page, attach screenshots or screen recordings of the following views:

1. **Header and navigation** - logo placement, navigation labels, sticky behaviour, menu states and header background.
2. **First full viewport** - hero composition, typography, background, primary action, any 3D/animated elements and spacing.
3. **One mid-page section** - section transitions, grids, card layout, decorative shapes and content widths.
4. **Hover/click states** - cards, buttons, navigation, dropdowns, overlays, filters and transitions.
5. **Footer** - layout, background, logo, social links and spacing.
6. **Mobile view** - mobile navigation, hero stacking, responsive typography and project/card layout.

Ask Google AI Studio to write a visual inventory from those screenshots before coding. The NIBM website should be inspired by the SLIIT reference's complete non-map interface and animation language, but must use NIBM/Leo brand assets and original NIBM content.

## Project-page reference split

- Main interface and motion reference: https://sliitleo.org/ProjectMap
- Publication/newsletter reference: https://kolonnawaleos.lk/witness-december-2025/
- Normal project archive: https://kolonnawaleos.lk/projects/
- Individual project-story page: https://kolonnawaleos.lk/paw-patrol-bruno-rescue-street-dog-sri-lanka/

Do not recreate the SLIIT project map. Build ordinary project cards and individual editorial project stories with admin-managed images, videos, captions, dates, category, project details, outcomes and related projects.
